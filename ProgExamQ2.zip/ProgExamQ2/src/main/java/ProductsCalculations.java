
/**
 *
 * @author Student
 */
public class ProductsCalculations {
    
public interface IProductCalculation
{
    double GetVat();

    double GetCommission();

    double GetTotal();
}

    
}


public class ProductCalculations : IProductCalculation
{
    // Declare variables
    private final double productPrice;

    private const double VAT_RATE = 0.15;
    private const double COMMISSION_RATE = 0.05;

    // Constructor
    public ProductCalculations(double price)
    {
        productPrice = price;
    }

    // Calculate VAT
    public double GetVat()
    {
        return productPrice * VAT_RATE;
    }

    // Calculate commission
    public double GetCommission()
    {
        return productPrice * COMMISSION_RATE;
    }

    // Calculate total sale amount
    public double GetTotal()
    {
        return productPrice + GetVat();
    }
}


class Program
{
    static void Main(string[] args)
    {
        // Create ProductCalculations object
        IProductCalculation calculation =
            new ProductCalculations(10000);

        // Display calculations
        Console.WriteLine("Product Price: R10000.00");

        Console.WriteLine("VAT: R" +
            calculation.GetVat().ToString("F2"));

        Console.WriteLine("Commission: R" +
            calculation.GetCommission().ToString("F2"));

        Console.WriteLine("Total Sale: R" +
            calculation.GetTotal().ToString("F2"));
    }
}
