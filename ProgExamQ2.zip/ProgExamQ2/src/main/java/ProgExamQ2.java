
package com.mycompany.progexamq2;

/**
 *
 * @author Student
 */
public class ProgExamQ2 { import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;

public class MattressSalesApp extends JFrame {

    private JTextField customerField, productField, priceField;
    private JTextField vatField, commissionField, totalField;

    private DefaultTableModel tableModel;

    private final DecimalFormat df =
            new DecimalFormat("R #,##0.00");

    public MattressSalesApp() {

        setTitle("Mattress Sales Management System");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel heading = new JLabel(
                "MATTRESS SALES MANAGEMENT SYSTEM",
                JLabel.CENTER);

        heading.setFont(new Font("Arial", Font.BOLD, 22));

        mainPanel.add(heading, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 10, 10));

        customerField = new JTextField();
        productField = new JTextField();
        priceField = new JTextField();

        vatField = new JTextField();
        commissionField = new JTextField();
        totalField = new JTextField();

        vatField.setEditable(false);
        commissionField.setEditable(false);
        totalField.setEditable(false);

        inputPanel.add(new JLabel("Customer Name:"));
        inputPanel.add(customerField);

        inputPanel.add(new JLabel("Product Name:"));
        inputPanel.add(productField);

        inputPanel.add(new JLabel("Product Price (R):"));
        inputPanel.add(priceField);

        inputPanel.add(new JLabel("VAT (15%):"));
        inputPanel.add(vatField);

        inputPanel.add(new JLabel("Commission (5%):"));
        inputPanel.add(commissionField);

        inputPanel.add(new JLabel("Total Sales Amount:"));
        inputPanel.add(totalField);

        JButton calculateButton = new JButton("Calculate");
        JButton saveButton = new JButton("Save Sale");
        JButton clearButton = new JButton("Clear");

        JPanel buttonPanel = new JPanel();

        buttonPanel.add(calculateButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(clearButton);

        inputPanel.add(new JLabel("Actions:"));
        inputPanel.add(buttonPanel);

        calculateButton.addActionListener(e -> calculate());

        saveButton.addActionListener(e -> saveSale());

        clearButton.addActionListener(e -> clearFields());

        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.add(inputPanel, BorderLayout.CENTER);

        mainPanel.add(topPanel, BorderLayout.CENTER);

        String[] columns = {
                "Customer Name",
                "Product Name",
                "Product Price",
                "VAT",
                "Commission",
                "Total Sales"
        };

        tableModel = new DefaultTableModel(columns, 0);

        JTable salesTable = new JTable(tableModel);

        JScrollPane scrollPane =
                new JScrollPane(salesTable);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(
                new JLabel(" SALES RECORDS"),
                BorderLayout.NORTH);

        bottomPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void calculate() {

        try {

            double price = Double.parseDouble(
                    priceField.getText().trim());

            if (price <= 0) {
                JOptionPane.showMessageDialog(
                        this, "Enter a price greater than zero.");
                return;
            }

            double vat = price * 0.15;
            double commission = price * 0.05;
            double total = price + vat + commission;

            vatField.setText(df.format(vat));
            commissionField.setText(df.format(commission));
            totalField.setText(df.format(total));

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this, "Please enter a valid product price.");

        }
    }

    private void saveSale() {

        if (customerField.getText().trim().isEmpty()
                || productField.getText().trim().isEmpty()
                || priceField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this, "Please complete all required fields.");
            return;
        }

        if (totalField.getText().isEmpty()) {
            calculate();

            if (totalField.getText().isEmpty()) {
                return;
            }
        }

        double price = Double.parseDouble(
                priceField.getText().trim());

        if (price <= 0) {
            JOptionPane.showMessageDialog(
                    this, "Price must be greater than zero.");
            return;
        }

        tableModel.addRow(new Object[] {
                customerField.getText().trim(),
                productField.getText().trim(),
                df.format(price),
                vatField.getText(),
                commissionField.getText(),
                totalField.getText()
        });

        JOptionPane.showMessageDialog(
                this, "Sale saved successfully!");

        clearFields();
    }

    private void clearFields() {

        customerField.setText("");
        productField.setText("");
        priceField.setText("");

        vatField.setText("");
        commissionField.setText("");
        totalField.setText("");
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new MattressSalesApp().setVisible(true);
        });
    }
}



Q.2.2 on the form include a text box to capture the customers name and combo box to capture the product name the mattress products available include 
*Cozy nights monarch
*restonic Barbados
*Sealy Phuket 
additionally add atext box to capture the product price

modify the code to 

import javax.swing.*;
import java.awt.*;

public class MattressSalesForm extends JFrame {

    JTextField txtCustomer, txtPrice;
    JTextField txtVAT, txtCommission, txtTotal;

    JComboBox<String> cmbProduct;

    public MattressSalesForm() {

        setTitle("Mattress Sales Management");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));

        panel.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        // Customer name text box
        panel.add(new JLabel("Customer Name:"));
        txtCustomer = new JTextField();
        panel.add(txtCustomer);

        // Product name combo box
        panel.add(new JLabel("Product Name:"));

        String[] products = {
            "Cozy nights monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);
        panel.add(cmbProduct);

        // Product price text box
        panel.add(new JLabel("Product Price (R):"));
        txtPrice = new JTextField();
        panel.add(txtPrice);

        // VAT text box
        panel.add(new JLabel("VAT (15%):"));
        txtVAT = new JTextField();
        txtVAT.setEditable(false);
        panel.add(txtVAT);

        // Commission text box
        panel.add(new JLabel("Commission (5%):"));
        txtCommission = new JTextField();
        txtCommission.setEditable(false);
        panel.add(txtCommission);

        // Total sales text box
        panel.add(new JLabel("Total Sales Amount:"));
        txtTotal = new JTextField();
        txtTotal.setEditable(false);
        panel.add(txtTotal);

        // Buttons
        JButton btnCalculate = new JButton("Calculate");
        JButton btnClear = new JButton("Clear");

        panel.add(btnCalculate);
        panel.add(btnClear);

        // Calculate button action
        btnCalculate.addActionListener(e -> calculate());

        // Clear button action
        btnClear.addActionListener(e -> clear());

        add(panel);
        setVisible(true);
    }

    private void calculate() {

        try {

            double price = Double.parseDouble(
                txtPrice.getText()
            );

            if (price <= 0) {
                JOptionPane.showMessageDialog(
                    this, "Enter a valid product price."
                );
                return;
            }

            double vat = price * 0.15;
            double commission = price * 0.05;
            double total = price + vat + commission;

            txtVAT.setText(String.format("R %.2f", vat));

            txtCommission.setText(
                String.format("R %.2f", commission)
            );

            txtTotal.setText(
                String.format("R %.2f", total)
            );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                this, "Please enter a valid price."
            );
        }
    }

    private void clear() {

        txtCustomer.setText("");
        cmbProduct.setSelectedIndex(0);
        txtPrice.setText("");
        txtVAT.setText("");
        txtCommission.setText("");
        txtTotal.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            () -> new MattressSalesForm()
        );
    }
}


    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}



<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mattress Sales Form</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }

        .form-container {
            max-width: 450px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #176b52;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #10523e;
        }

        #result {
            margin-top: 20px;
            padding: 12px;
            background: #e8f5e9;
            border-radius: 5px;
            display: none;
        }
    </style>
</head>

<body>

<div class="form-container">
    <h2>Mattress Sales Form</h2>

    <form id="mattressForm">

        <label for="customerName">Customer Name</label>
        <input
            type="text"
            id="customerName"
            placeholder="Enter customer name"
            required
        >

        <label for="productName">Product Name</label>
        <select id="productName" required>
            <option value="">Select a mattress</option>
            <option value="Coz Nights Monarch">Coz Nights Monarch</option>
            <option value="Restonic Barbados">Restonic Barbados</option>
            <option value="Sealy Phuket">Sealy Phuket</option>
        </select>

        <label for="productPrice">Product Price (R)</label>
        <input
            type="number"
            id="productPrice"
            placeholder="Enter product price"
            min="0"
            step="0.01"
            required
        >

        <button type="submit">Submit Form</button>

    </form>

    <div id="result"></div>
</div>

<script>
    document.getElementById("mattressForm")
        .addEventListener("submit", function(event) {

        event.preventDefault();

        const customer = document.getElementById("customerName").value;
        const product = document.getElementById("productName").value;
        const price = document.getElementById("productPrice").value;

        const result = document.getElementById("result");

        result.style.display = "block";

        result.innerHTML = `
            <h3>Sales Details</h3>
            <p><strong>Customer:</strong> ${customer}</p>
            <p><strong>Product:</strong> ${product}</p>
            <p><strong>Price:</strong> R${Number(price).toFixed(2)}</p>
        `;
    });
</script>

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mattress Sales System</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }

        .form-container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #176b52;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #176b52;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background: #10523e;
        }

        #result {
            margin-top: 20px;
            padding: 15px;
            background: #e8f5e9;
            border-radius: 5px;
            display: none;
            line-height: 1.7;
        }
    </style>
</head>

<body>

<div class="form-container">

    <h2>Mattress Sales System</h2>

    <form id="mattressForm">

        <label for="customerName">Customer Name</label>
        <input
            type="text"
            id="customerName"
            placeholder="Enter customer name"
            required
        >

        <label for="productName">Product Name</label>
        <select id="productName" required>
            <option value="">Select a mattress</option>
            <option value="Coz Nights Monarch">Coz Nights Monarch</option>
            <option value="Restonic Barbados">Restonic Barbados</option>
            <option value="Sealy Phuket">Sealy Phuket</option>
        </select>

        <label for="productPrice">Product Price (R)</label>
        <input
            type="number"
            id="productPrice"
            placeholder="Enter product price"
            min="0.01"
            step="0.01"
            required
        >

        <button type="submit">Process Sale</button>

    </form>

    <div id="result"></div>

</div>

<script>

    // Calculation rates
    const VAT_RATE = 0.15;
    const COMMISSION_RATE = 0.05;

    document.getElementById("mattressForm")
        .addEventListener("submit", function(event) {

        event.preventDefault();

        // Capture customer information
        const customer = document.getElementById("customerName").value.trim();
        const product = document.getElementById("productName").value;
        const price = Number(document.getElementById("productPrice").value);

        if (!customer || !product || !Number.isFinite(price) || price <= 0) {
            alert("Please enter valid sales information.");
            return;
        }

        // Calculate VAT
        const vat = price * VAT_RATE;

        // Calculate commission
        const commission = price * COMMISSION_RATE;

        // Calculate total including VAT
        const total = price + vat;

        // Format currency
        const money = amount => "R" + amount.toFixed(2);

        // Capture date and time
        const saleDate = new Date().toLocaleString("en-ZA");

        // Prepare sales information
        const salesData = `
====================================
       MATTRESS SALES RECORD
====================================

Date: ${saleDate}

Customer Name: ${customer}

Product Name: ${product}

Product Price: ${money(price)}

VAT (15%): ${money(vat)}

Commission (5%): ${money(commission)}

------------------------------------
TOTAL AMOUNT: ${money(total)}
====================================

`;

        // Display results
        const result = document.getElementById("result");

        result.replaceChildren();

        const heading = document.createElement("h3");
        heading.textContent = "Sales Processed Successfully";

        const details = document.createElement("pre");
        details.textContent = salesData;

        result.appendChild(heading);
        result.appendChild(details);
        result.style.display = "block";

        // Save information to data.txt
        const file = new Blob(
            [salesData],
            { type: "text/plain;charset=utf-8" }
        );

        const downloadLink = document.createElement("a");

        const fileURL = URL.createObjectURL(file);

        downloadLink.href = fileURL;
        downloadLink.download = "data.txt";

        document.body.appendChild(downloadLink);
        downloadLink.click();

        downloadLink.remove();
        URL.revokeObjectURL(fileURL);

        alert("Sales information has been downloaded as data.txt");

    });

</script>

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mattress Sales System</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
        }

        /* Menu bar */
        .menu-bar {
            background: #176b52;
            display: flex;
            padding: 0 15px;
        }

        .menu {
            position: relative;
        }

        .menu-button {
            background: #176b52;
            color: white;
            border: none;
            padding: 15px 20px;
            cursor: pointer;
            font-size: 16px;
            width: auto;
            margin: 0;
        }

        .menu-button:hover {
            background: #10523e;
        }

        .dropdown {
            display: none;
            position: absolute;
            background: white;
            min-width: 150px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 10;
        }

        .dropdown button {
            display: block;
            width: 100%;
            background: white;
            color: black;
            text-align: left;
            padding: 12px;
            border: none;
            margin: 0;
            border-radius: 0;
        }

        .dropdown button:hover {
            background: #e8f5e9;
        }

        .menu:hover .dropdown {
            display: block;
        }

        /* Form */
        .form-container {
            max-width: 500px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #176b52;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .process-button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #176b52;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .process-button:hover {
            background: #10523e;
        }

        #result {
            margin-top: 20px;
            padding: 15px;
            background: #e8f5e9;
            border-radius: 5px;
            display: none;
            white-space: pre-wrap;
        }

    </style>
</head>

<body>

<!-- MENU SYSTEM -->

<div class="menu-bar">

    <!-- FILE MENU -->
    <div class="menu">

        <button class="menu-button">File</button>

        <div class="dropdown">
            <button onclick="exitApp()">Exit</button>
        </div>

    </div>

    <!-- TOOLS MENU -->
    <div class="menu">

        <button class="menu-button">Tools</button>

        <div class="dropdown">
            <button onclick="processSale()">Process</button>
            <button onclick="clearForm()">Clear</button>
        </div>

    </div>

</div>


<!-- MAIN FORM -->

<div class="form-container">

    <h2>Mattress Sales System</h2>

    <form id="mattressForm">

        <label for="customerName">Customer Name</label>

        <input
            type="text"
            id="customerName"
            placeholder="Enter customer name"
            required
        >

        <label for="productName">Product Name</label>

        <select id="productName" required>

            <option value="">Select a mattress</option>

            <option value="Coz Nights Monarch">
                Coz Nights Monarch
            </option>

            <option value="Restonic Barbados">
                Restonic Barbados
            </option>

            <option value="Sealy Phuket">
                Sealy Phuket
            </option>

        </select>


        <label for="productPrice">Product Price (R)</label>

        <input
            type="number"
            id="productPrice"
            placeholder="Enter product price"
            min="0.01"
            step="0.01"
            required
        >

        <button type="submit" class="process-button">
            Process Sale
        </button>

    </form>


    <div id="result"></div>

</div>


<script>

    // VAT and commission rates
    const VAT_RATE = 0.15;
    const COMMISSION_RATE = 0.05;


    // PROCESS SALE FUNCTION
    // Used by both the Process menu and Process Sale button

    function processSale() {

        const customer =
            document.getElementById("customerName").value.trim();

        const product =
            document.getElementById("productName").value;

        const price =
            Number(document.getElementById("productPrice").value);


        // Validate input
        if (!customer || !product ||
            !Number.isFinite(price) || price <= 0) {

            alert("Please complete all fields correctly.");
            return;
        }


        // Perform calculations
        const vat = price * VAT_RATE;

        const commission = price * COMMISSION_RATE;

        const total = price + vat;


        // Format currency
        const money = amount => "R" + amount.toFixed(2);


        // Get date and time
        const saleDate = new Date().toLocaleString("en-ZA");


        // Prepare data for text file
        const salesData = `
====================================
       MATTRESS SALES RECORD
====================================

Date: ${saleDate}

Customer Name: ${customer}

Product Name: ${product}

Product Price: ${money(price)}

VAT (15%): ${money(vat)}

Commission (5%): ${money(commission)}

------------------------------------
TOTAL AMOUNT: ${money(total)}
====================================

`;


        // Display results
        const result = document.getElementById("result");

        result.style.display = "block";

        result.textContent = salesData;


        // Save data to data.txt
        const file = new Blob(
            [salesData],
            { type: "text/plain;charset=utf-8" }
        );

        const fileURL = URL.createObjectURL(file);

        const downloadLink = document.createElement("a");

        downloadLink.href = fileURL;

        downloadLink.download = "data.txt";

        document.body.appendChild(downloadLink);

        downloadLink.click();

        downloadLink.remove();

        setTimeout(() => URL.revokeObjectURL(fileURL), 1000);

        alert("Sale processed successfully. data.txt downloaded.");

    }


    // CLEAR FUNCTION

    function clearForm() {

        // Clear customer name
        document.getElementById("customerName").value = "";

        // Reset combo box to selected index 0
        document.getElementById("productName").selectedIndex = 0;

        // Clear product price
        document.getElementById("productPrice").value = "";

        // Clear results
        document.getElementById("result").textContent = "";

        document.getElementById("result").style.display = "none";

    }


    // EXIT FUNCTION

    function exitApp() {

        const confirmExit = confirm(
            "Are you sure you want to exit the application?"
        );

        if (confirmExit) {

            window.close();

            // Browsers generally block closing tabs
            // that were not opened using JavaScript.

        }

    }


    // PROCESS BUTTON EVENT
    // Calls the same processSale() function

    document.getElementById("mattressForm")
        .addEventListener("submit", function(event) {

            event.preventDefault();

            processSale();

        });

</script>

</body>
</html>
