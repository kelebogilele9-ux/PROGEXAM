import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import MattressSales.java.;

public class ProductTest {

    String[] products = {
        "Single Mattress",
        "Double Mattress",
        "Queen Mattress",
        "King Mattress"
    };

    int[] sales = {25, 40, 60, 35};

    // Test total products sold
    @Test
    public void testTotalProductSold() {

        Product product = new Product(products, sales);

        assertEquals(160, product.getTotalProductSold());
    }

    // Test average products sold
    @Test
    public void testAverageProductSold() {

        Product product = new Product(products, sales);

        assertEquals(40.0,
                product.getAverageProductSold(), 0.001);
    }

    // Test most popular product
    @Test
    public void testMostPopularProduct() {

        Product product = new Product(products, sales);

        assertEquals("Queen Mattress",
                product.getMostPopularProduct());
    }
}
