import java.util.Scanner;

public class MattressSales {

    public static void main(String[] args) {

        // Mattress products
        try (Scanner input = new Scanner(System.in)) {
            // Mattress products
            String[] products = {
                "Single Mattress",
                "Double Mattress",
                "Queen Mattress",
                "King Mattress"
            };
            
            int[] sales = new int[products.length];
            
            int totalSales = 0;
            int highestSales = 0;
            String mostPopularProduct = "";
            
            // Enter sales for each product
            System.out.println("==================================");
            System.out.println("     MATTRESS SALES SYSTEM");
            System.out.println("==================================");
            
            for (int i = 0; i < products.length; i++) {
                
                System.out.print("Enter sales for "
                        + products[i] + ": ");
                
                sales[i] = input.nextInt();
                
                // Calculate total sales
                totalSales += sales[i];
                
                // Identify most popular product
                if (sales[i] > highestSales) {
                    highestSales = sales[i];
                    mostPopularProduct = products[i];
                }
            }
            
            // Calculate average sales per product
            double averageSales =
                    (double) totalSales / products.length;
            
            // Display sales results
            System.out.println("\n==================================");
            System.out.println("       SALES REPORT");
            System.out.println("==================================");
            
            System.out.println("\nPRODUCT SALES:");
            
            for (int i = 0; i < products.length; i++) {
                System.out.println(products[i] + ": "
                        + sales[i] + " units");
            }
            
            System.out.println("\n----------------------------------");
            System.out.println("Total products sold: "
                    + totalSales);
            
            System.out.printf("Average products sold per product: %.2f%n",
                    averageSales);
            
            System.out.println("Most popular product: "
                    + mostPopularProduct);
            
            System.out.println("Highest sales: "
                    + highestSales + " units");
            
            System.out.println("==================================");
        }
    }
}
