public interface Products {

    int getTotalProductSold();

    double getAverageProductSold();

    String getMostPopularProduct();



public class Product implements Products {

    private String[] products;
    private int[] sales;

    // Constructor
    public Product(String[] products, int[] sales) {
        this.products = products;
        this.sales = sales;
    }

    // Method to calculate total products sold
    @Override
    public int getTotalProductSold() {

        int total = 0;

        for (int i = 0; i < sales.length; i++) {
            total += sales[i];
        }

        return total;
    }

    // Method to calculate average products sold
    @Override
    public double getAverageProductSold() {

        if (sales.length == 0) {
            return 0;
        }

        return (double) getTotalProductSold()
                / sales.length;
    }

    // Method to determine the most popular product
    @Override
    public String getMostPopularProduct() {

        if (sales.length == 0) {
            return "No products available";
        }

        int highestSales = sales[0];
        int index = 0;

        for (int i = 1; i < sales.length; i++) {

            if (sales[i] > highestSales) {
                highestSales = sales[i];
                index = i;
            }
        }

        return products[index];
    }
}

/*create*/ main class 
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] products = {
            "Single Mattress",
            "Double Mattress",
            "Queen Mattress",
            "King Mattress"
        };

        int[] sales = new int[products.length];

        System.out.println("MATTRESS SALES SYSTEM");
        System.out.println("---------------------");

        // Enter product sales
        for (int i = 0; i < products.length; i++) {

            System.out.print("Enter sales for "
                    + products[i] + ": ");

            sales[i] = input.nextInt();
        }

        // Create Product object
        Product product = new Product(products, sales);

        // Display sales report
        System.out.println("\nSALES REPORT");
        System.out.println("---------------------");

        System.out.println("Total products sold: "
                + product.getTotalProductSold());

        System.out.println("Average products sold: "
                + product.getAverageProductSold());

        System.out.println("Most popular product: "
                + product.getMostPopularProduct());

        input.close();
    }
}

