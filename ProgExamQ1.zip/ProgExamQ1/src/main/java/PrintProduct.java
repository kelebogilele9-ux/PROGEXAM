

/**
 *
 * @author Student
 */
public class PrintProduct {
    private Product product;

    // Constructor
    public PrintProduct(Product product) {
        this.product = product;
    }

    // Print total product sales
    public void printTotalProductSales() {

        System.out.println("Total products sold: "
                + product.getTotalProductSold());
    }

    // Print average product sales
    public void printAverageProductSales() {

        System.out.println("Average products sold: "
                + product.getAverageProductSold());
    }

    // Print most popular product
    public void printMostPopularSale() {

        System.out.println("Most popular product: "
                + product.getMostPopularProduct());
    }
}

public class PrintProduct.java {

    public static void main(String[] args) {

        scanner input = new scanner(System.in);

        String[] products = {
            "Single Mattress",
            "Double Mattress",
            "Queen Mattress",
            "King Mattress"
        };

        int[] sales = new int[products.length];

        System.out.println("MATTRESS SALES SYSTEM");

        // Enter sales
        for (int i = 0; i < products.length; i++) {

            System.out.print("Enter sales for "
                    + products[i] + ": ");

            sales[i] = input.nextInt();
        }

        // Create Product object
        Product product = new Product(products, sales);

        // Create PrintProduct object
        PrintProduct report = new PrintProduct(product);

        // Print sales report
        System.out.println("\n===== SALES REPORT =====");

        report.printTotalProductSales();

        report.printAverageProductSales();

        report.printMostPopularSale();

        System.out.println("========================");

        input.close();
    }
}

    
